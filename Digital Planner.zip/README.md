
  # Digital Planner

  This is a code bundle for Digital Planner. The original project is available at https://www.figma.com/design/25oAK7dq5lTx9OKv3xEeCO/Digital-Planner.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  